import Image from "next/image";
import LocationTrackingDashboard from "../../components/Dashboard";
import EnvironmentalDashboard from "../../components/Graph";
import Title from "../../components/Landing";

export default function Home() {
  return (
    <div>
      <Title />
      <LocationTrackingDashboard />
      <EnvironmentalDashboard />
    </div>
  );
}
