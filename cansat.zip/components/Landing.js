'use client'
import React, { useState } from 'react';

export default function Title() {
    const [activeTab, setActiveTab] = useState('telemetry');

    return (
        <div className="w-full pt-8 pb-4">
            <div className="max-w-7xl mx-auto px-6">
                <h1 className="text-3xl md:text-4xl font-semibold text-gray-900 tracking-tight">
                    CanSat-A
                </h1>
                <p className="mt-1 text-lg text-gray-500 font-light">
                    Mission Control Dashboard
                </p>

                <div className="mt-8 border-b border-gray-200">
                    <div className="flex space-x-8">
                        <button
                            onClick={() => setActiveTab('telemetry')}
                            className={`pb-4 px-1 font-medium text-sm ${activeTab === 'telemetry'
                                ? 'text-blue-500 border-b-2 border-blue-500'
                                : 'text-gray-500 hover:text-gray-700'
                                }`}
                        >
                            Real-time Telemetry
                        </button>
                        <button
                            onClick={() => setActiveTab('forecasting')}
                            className={`pb-4 px-1 font-medium text-sm ${activeTab === 'forecasting'
                                ? 'text-blue-500 border-b-2 border-blue-500'
                                : 'text-gray-500 hover:text-gray-700'
                                }`}
                        >
                            Forecasting
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
}